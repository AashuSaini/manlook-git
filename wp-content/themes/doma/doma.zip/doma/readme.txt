 * Theme Name:  Doma
 * Theme URI:   http://doma.wp2.zootempate.com
 * Author:      Zootemplate
 * Author URI:  http://zootemplate.com/
 * Description: Doma is an impressive, super light, flexible and feature rich WordPress WooCommerce Theme for your online shop.
 * Version:     1.3.6
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Tags:        two-columns, left-sidebar, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready
 * Text Domain: doma
 *
 * This theme, like WordPress, is licensed under the GPL. Use it to make something cool, have fun, and share what you've learned with others.
First and foremost we want to give a huge thank you for purchasing this WordPress Theme.
We greatly appreciate your feedback from you on how, if anywhere, you would like this documentation improved.
If you have any further question, please kindly contact to us via our Helpdesk.
Zoo Landscaping Wordpress theme is a WooCommerce Wordpress theme designed and developed for use with Wordpress 4.7 or higher.
The code was written to be backwards compatible where possible, however we recommend you use the current WP version when possible.
If you are not using WordPress 4.7 or higher and can upgrade your site we recommend you do this before installation.
Although every effort has been made to ensure the theme is bug free and easy to use there is always a chance errors may occur.
If you do find a problem please notify us immediately through our Help Desk so we can ensure it gets fixed as quickly as possible.

WordPress FAQ: http://codex.WordPress.org/FAQ_New_To_WordPress
Full Installation Guide: http://codex.WordPress.org/First_Steps_With_WordPress
WordPress Video Tutorials: http://wp.tutsplus.com/sessions/wp101-basix-training/

